var express= require("express");
var app=express();

var mysql=require('mysql');
var bodyParser= require("body-parser")
app.set("view engine","ejs");
app.use(bodyParser.urlencoded({extended: true}));
app.use(express.static(__dirname+ "/public"));

var connection=mysql.createConnection({

	host:'localhost',
	user:'root',
	database:'join_us'
});

// app.get('/',function(req,res){
// 	console.log("Someone requested us")
//  });

// app.get('/',function(req,res){
// 	console.log(req);
// 	var q='SELECT COUNT(*) as count FROM users';
// 	connection.query(q,function(error,result)
// 					{
// 		if(error) throw error;
// 		var msg= "We have " + result[0].count + " users";
// 		res.send(msg);
// 	});
// 	})

app.get('/',function(req,res){
	
	var q='SELECT COUNT(*) AS count FROM users';
	
	  connection.query(q,function(error,result){
	if(error) throw error;
	var count = result[0].count;
	
	  res.render("home",{user_no : count,favourite_colour: 'blue'});	
	});
	});

// app.post('/register',function(req,res){
// 	var person={email: req.body.email};
// 	connection.query('INSERT INTO users SET?',person,function(err,
// 	 result){
// 		console.log(err);
// 		console.log(result);
// 		res.redirect("/")
// 	});
// });

// app.post("/register",function(req,res){
	
// 	var person = {
// 	    email: req.body.email
// };
	
//  connection.query('INSERT INTO users SET ?',person,function(err,result){
// 	if(err) throw err;
// 	console.log(result);
// });
// });
	
app.post("/register",function(req,res){
	var person= {
		email:req.body.email
				};
	connection.query('INSERT INTO users SET ? ',person,function(err,result){
		if (err) throw err;
		//res.send("Thanks for joining our membership!!")
		res.redirect("/");
		console.log("New user registered: "+ req.body.email)
		
	});
});






app.get('/joke',function(req,res){
	console.log("Joke requested");
	var joke= "Kya bolti Public!! Bole toh Takleef!!"
	res.send(joke);
	
	
});

// function between(min, max){
//     return Math.floor(Math.random()*(max-min+1)+min);
//     }

// function randomNumber(min, max){
//     const r = Math.random()*(max-min) + min
//     return Math.floor(r)
// }

app.get('/housiee',function(req,res){
	console.log("Random Number requested");
	var num= Math.floor(Math.random()*(15-1+1)+1);
	res.send("Housiee number is " + num);
});

app.get("/random_num", function(req, res){
 var num = Math.floor((Math.random() * 10) + 1);
 res.send("Your lucky number is " + num);
});

app.listen(3000,function(){
	console.log("The Port is 3000!");
});




